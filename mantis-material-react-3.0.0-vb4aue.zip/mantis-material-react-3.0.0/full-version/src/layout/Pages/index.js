import { Outlet } from 'react-router-dom';

// ==============================|| LAYOUT - BLANK PAGES ||============================== //

const PagesLayout = () => {
  return <Outlet />;
};

export default PagesLayout;
