import Error404 from 'views/maintenance/404';

// ==============================|| ERROR 404 - MAIN ||============================== //

export default function notfound() {
  return <Error404 />;
}
