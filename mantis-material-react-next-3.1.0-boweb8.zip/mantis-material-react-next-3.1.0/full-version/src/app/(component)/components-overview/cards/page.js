import ComponentCard from 'views/components-overview/cards';

export default function CardPage() {
  return <ComponentCard />;
}
