import ComponentColor from 'views/components-overview/color';

export default function ColorPage() {
  return <ComponentColor />;
}
