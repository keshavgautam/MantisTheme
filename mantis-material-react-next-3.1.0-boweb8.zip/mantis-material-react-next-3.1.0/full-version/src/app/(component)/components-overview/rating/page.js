import ComponentRating from 'views/components-overview/rating';

export default function RatingPage() {
  return <ComponentRating />;
}
