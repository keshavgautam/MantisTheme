import ComponentSwitch from 'views/components-overview/switch';

export default function SwitchPage() {
  return <ComponentSwitch />;
}
