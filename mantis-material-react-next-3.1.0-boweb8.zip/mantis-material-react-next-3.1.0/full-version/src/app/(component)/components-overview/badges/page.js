import ComponentBadge from 'views/components-overview/badges';

export default function BadgePage() {
  return <ComponentBadge />;
}
