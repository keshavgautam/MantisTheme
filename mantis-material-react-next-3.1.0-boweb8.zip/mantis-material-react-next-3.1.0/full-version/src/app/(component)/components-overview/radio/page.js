import ComponentRadio from 'views/components-overview/radio';

export default function RadioPage() {
  return <ComponentRadio />;
}
