import ComponentSnackbar from 'views/components-overview/snackbar';

export default function SnackbarPage() {
  return <ComponentSnackbar />;
}
