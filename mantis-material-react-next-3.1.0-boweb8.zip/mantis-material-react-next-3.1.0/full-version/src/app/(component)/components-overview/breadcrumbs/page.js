import ComponentBreadcrumb from 'views/components-overview/breadcrumbs';

export default function BreadcrumbPage() {
  return <ComponentBreadcrumb />;
}
