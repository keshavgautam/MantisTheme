import ComponentSpeeddial from 'views/components-overview/speeddial';

export default function SpeeddialPage() {
  return <ComponentSpeeddial />;
}
