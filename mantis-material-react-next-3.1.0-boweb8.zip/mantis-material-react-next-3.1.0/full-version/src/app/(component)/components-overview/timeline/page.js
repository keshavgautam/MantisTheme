import ComponentTimeline from 'views/components-overview/timeline';

export default function TimelinePage() {
  return <ComponentTimeline />;
}
