import ComponentAutocomplete from 'views/components-overview/autocomplete';

export default function AutoCompletePage() {
  return <ComponentAutocomplete />;
}
