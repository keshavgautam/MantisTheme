import ComponentChip from 'views/components-overview/chips';

export default function ChipPage() {
  return <ComponentChip />;
}
