import ComponentList from 'views/components-overview/lists';

export default function ListPage() {
  return <ComponentList />;
}
