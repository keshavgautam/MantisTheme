import Buttons from 'views/components-overview/buttons';

export default function ButtonsPage() {
  return <Buttons />;
}
