import ComponentProgress from 'views/components-overview/progress';

export default function ProgressPage() {
  return <ComponentProgress />;
}
