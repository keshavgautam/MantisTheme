import ComponentShadow from 'views/components-overview/shadows';

export default function ShadowPage() {
  return <ComponentShadow />;
}
