import ComponentCheckbox from 'views/components-overview/checkbox';

export default function CheckboxPage() {
  return <ComponentCheckbox />;
}
