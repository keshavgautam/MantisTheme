import ComponentTooltip from 'views/components-overview/tooltip';

export default function TooltipPage() {
  return <ComponentTooltip />;
}
