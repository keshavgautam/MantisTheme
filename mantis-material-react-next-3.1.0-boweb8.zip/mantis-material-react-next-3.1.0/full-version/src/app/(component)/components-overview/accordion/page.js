import ComponentAccordion from 'views/components-overview/accordion';

export default function AccordiPage() {
  return <ComponentAccordion />;
}
