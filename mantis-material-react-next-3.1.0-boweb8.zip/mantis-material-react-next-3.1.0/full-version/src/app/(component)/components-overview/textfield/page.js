import ComponentTextField from 'views/components-overview/textfield';

export default function TextFieldPage() {
  return <ComponentTextField />;
}
