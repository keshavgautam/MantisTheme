import ComponentTreeView from 'views/components-overview/treeview';

export default function TreeViewPage() {
  return <ComponentTreeView />;
}
