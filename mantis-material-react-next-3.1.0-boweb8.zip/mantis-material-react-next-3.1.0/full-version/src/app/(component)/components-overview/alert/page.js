import ComponentAlert from 'views/components-overview/alert';

export default function AlertPage() {
  return <ComponentAlert />;
}
