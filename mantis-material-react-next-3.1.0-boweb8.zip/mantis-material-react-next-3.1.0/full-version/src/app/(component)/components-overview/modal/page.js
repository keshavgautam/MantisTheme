import ComponentModal from 'views/components-overview/modal';

export default function ModalPage() {
  return <ComponentModal />;
}
