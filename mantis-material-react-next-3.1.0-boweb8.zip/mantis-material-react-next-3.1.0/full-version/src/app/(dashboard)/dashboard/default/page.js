import DashboardDefault from 'views/dashboard/default';

export default function DefaultDashboardPage() {
  return <DashboardDefault />;
}
