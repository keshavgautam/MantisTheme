import OrgChart from 'views/charts/org-chart';

// ==============================|| PAGE ||============================== //

export default function OrgChartPage() {
  return <OrgChart />;
}
