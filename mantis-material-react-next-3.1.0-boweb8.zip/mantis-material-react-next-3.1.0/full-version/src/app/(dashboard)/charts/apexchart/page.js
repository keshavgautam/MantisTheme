import ApexChartView from 'views/charts/apexchart';

// ==============================|| PAGE ||============================== //

export default function ApexChartPage() {
  return <ApexChartView />;
}
