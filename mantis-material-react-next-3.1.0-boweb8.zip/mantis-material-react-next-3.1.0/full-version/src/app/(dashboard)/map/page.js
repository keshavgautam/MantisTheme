import Map from 'views/map';

// ==============================|| PAGE ||============================== //

export default function MapPage() {
  return <Map />;
}
