import InvoiceListApp from 'views/apps/invoice/list';

// ==============================|| PAGE ||============================== //

export default function InvoiceListAppPage() {
  return <InvoiceListApp />;
}
