import ProductsApp from 'views/apps/e-commerce/products';

// ==============================|| PAGE ||============================== //

export default function ProductsAppPage() {
  return <ProductsApp />;
}
