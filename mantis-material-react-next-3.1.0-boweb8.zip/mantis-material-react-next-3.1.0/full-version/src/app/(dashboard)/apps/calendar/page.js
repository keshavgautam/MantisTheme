import CalendarApp from 'views/apps/calendar';

// ==============================|| PAGE ||============================== //

export default function CalendarAppPage() {
  return <CalendarApp />;
}
