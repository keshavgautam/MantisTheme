import CollapseTable from 'views/tables/mui-table/collapse';

// ==============================|| PAGE ||============================== //

export default function CollapseTablePage() {
  return <CollapseTable />;
}
