import EnhancedTable from 'views/tables/mui-table/enhanced';

// ==============================|| PAGE ||============================== //

export default function EnhancedTablePage() {
  return <EnhancedTable />;
}
