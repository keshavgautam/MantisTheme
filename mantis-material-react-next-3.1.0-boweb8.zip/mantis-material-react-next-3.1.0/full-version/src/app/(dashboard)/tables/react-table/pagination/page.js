import PagingTable from 'views/tables/react-table/pagination';

// ==============================|| PAGE ||============================== //

export default function PagingTablePage() {
  return <PagingTable />;
}
