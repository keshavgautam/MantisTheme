import SortTable from 'views/tables/react-table/sorting';

// ==============================|| PAGE ||============================== //

export default function SortTablePage() {
  return <SortTable />;
}
