import VirtualTable from 'views/tables/react-table/virtualized';

// ==============================|| PAGE ||============================== //

export default function VirtualTablePage() {
  return <VirtualTable />;
}
