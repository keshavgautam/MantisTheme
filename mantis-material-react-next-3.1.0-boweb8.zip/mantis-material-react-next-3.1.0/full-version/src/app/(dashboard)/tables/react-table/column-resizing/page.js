import ResizingTable from 'views/tables/react-table/column-resizing';

// ==============================|| PAGE ||============================== //

export default function ResizingTablePage() {
  return <ResizingTable />;
}
