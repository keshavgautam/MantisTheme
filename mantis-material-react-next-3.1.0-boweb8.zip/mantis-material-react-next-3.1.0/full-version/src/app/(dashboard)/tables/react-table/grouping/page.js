import GroupTable from 'views/tables/react-table/grouping';

// ==============================|| PAGE ||============================== //

export default function GroupTablePage() {
  return <GroupTable />;
}
