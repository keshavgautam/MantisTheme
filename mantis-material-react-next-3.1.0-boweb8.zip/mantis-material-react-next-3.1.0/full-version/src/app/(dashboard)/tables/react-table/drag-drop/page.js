import DragDropTable from 'views/tables/react-table/drag-drop';

// ==============================|| PAGE ||============================== //

export default function DragDropTablePage() {
  return <DragDropTable />;
}
