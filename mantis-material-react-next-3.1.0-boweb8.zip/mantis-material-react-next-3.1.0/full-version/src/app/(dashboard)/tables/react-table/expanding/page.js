import ExpandTable from 'views/tables/react-table/expanding';

// ==============================|| PAGE ||============================== //

export default function ExpandTablePage() {
  return <ExpandTable />;
}
