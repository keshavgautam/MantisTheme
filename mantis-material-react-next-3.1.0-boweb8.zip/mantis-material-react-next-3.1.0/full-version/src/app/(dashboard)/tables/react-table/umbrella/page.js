import UmbrellaTable from 'views/tables/react-table/umbrella';

// ==============================|| PAGE ||============================== //

export default function UmbrellaTablePage() {
  return <UmbrellaTable />;
}
