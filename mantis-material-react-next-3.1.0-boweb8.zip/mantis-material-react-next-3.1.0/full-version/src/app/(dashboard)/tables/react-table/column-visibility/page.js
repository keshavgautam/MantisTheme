import ColumnVisiTable from 'views/tables/react-table/column-visibility';

// ==============================|| PAGE ||============================== //

export default function ColumnVisiTablePage() {
  return <ColumnVisiTable />;
}
