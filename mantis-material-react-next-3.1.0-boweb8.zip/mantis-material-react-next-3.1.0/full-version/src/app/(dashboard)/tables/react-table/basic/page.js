import BasicTable from 'views/tables/react-table/basic';

// ==============================|| PAGE ||============================== //

export default function BasicTablePage() {
  return <BasicTable />;
}
