import WidgetChart from 'views/widget/chart';

export default function WidgetChartPage() {
  return <WidgetChart />;
}
