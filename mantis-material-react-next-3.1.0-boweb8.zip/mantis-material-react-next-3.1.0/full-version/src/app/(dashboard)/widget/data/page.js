import DataChart from 'views/widget/data';

export default function DataChartPage() {
  return <DataChart />;
}
