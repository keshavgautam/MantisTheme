import ActionBarLayout from 'views/forms/layouts/action-bar';

//============================== PAGES =====================//

export default function ActionBarLayoutPage() {
  return <ActionBarLayout />;
}
