import ColumnsLayouts from 'views/forms/layouts/multi-column';

// ==============================|| PAGE ||============================== //

export default function ColumnsLayoutsPage() {
  return <ColumnsLayouts />;
}
