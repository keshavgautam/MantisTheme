import EditorPlugin from 'views/forms/plugins/editor';

// ================= PAGE ======================= //

export default function EditorPluginPage() {
  return <EditorPlugin />;
}
