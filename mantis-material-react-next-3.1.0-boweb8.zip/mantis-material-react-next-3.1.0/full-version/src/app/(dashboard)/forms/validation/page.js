import FormsValidation from 'views/forms/validation';

// ==============================|| PAGE ||============================== //

export default function FormsValidationPage() {
  return <FormsValidation />;
}
