import Error500 from 'views/maintenance/500';

// ==============================|| PAGE - ERROR 500 ||============================== //

export default function Error500Page() {
  return <Error500 />;
}
