import CodeVerification from 'views/auth/code-verification';

// ==============================|| PAGE ||============================== //

export default function CodeVerificationPage() {
  return <CodeVerification />;
}
