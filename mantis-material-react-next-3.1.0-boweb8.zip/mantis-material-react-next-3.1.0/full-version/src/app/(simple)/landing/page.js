// project import
import Landing from 'views/landing';

export default function HomePage() {
  return <Landing />;
}
